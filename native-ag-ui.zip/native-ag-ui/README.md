# 原生AG-UI实现

这是一个使用原生技术栈实现的AG-UI前后端应用。

## 技术栈

### 后端
- Python 3.9+ (原生HTTP服务器)
- 无外部框架依赖
- WebSocket支持实时通信
- AG-UI协议兼容

### 前端
- 原生HTML5 + CSS3 + JavaScript
- WebSocket客户端
- 响应式设计
- 暗色/亮色主题切换

## 功能特性

- 💬 实时聊天界面
- 🔄 双向状态同步
- 🧩 结构化消息显示
- 🛠️ 工具调用支持
- 🎨 现代化UI设计
- 📱 移动端适配

## 快速开始

### 启动后端服务
```bash
cd backend
python server.py
```

### 打开前端界面
```bash
cd frontend
python -m http.server 8080
```

然后访问 http://localhost:8080

## 项目结构

```
native-ag-ui/
├── backend/
│   ├── server.py          # 主服务器
│   ├── ag_ui_protocol.py  # AG-UI协议实现
│   ├── websocket_handler.py # WebSocket处理
│   └── agent_simulator.py # 智能体模拟器
├── frontend/
│   ├── index.html         # 主页面
│   ├── style.css          # 样式文件
│   ├── script.js          # 主要逻辑
│   └── ag-ui-client.js    # AG-UI客户端
└── README.md
```

## AG-UI协议支持

支持以下AG-UI事件类型：
- TEXT_MESSAGE_START/CONTENT/END
- TOOL_CALL_START/ARGS/END
- STATE_SNAPSHOT/DELTA
- RUN_STARTED/FINISHED/ERROR
- CUSTOM事件